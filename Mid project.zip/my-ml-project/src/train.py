# # Credit Analysis ML Web App
#

import pandas as pd
import numpy as np

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODELS_DIR = ROOT / "models"
MODELS_DIR.mkdir(exist_ok=True)

df = pd.read_csv(ROOT / "data" / "raw" / "cs-training.csv")





df["MonthlyIncome"]=df["MonthlyIncome"].fillna(df["MonthlyIncome"].median())

df["NumberOfDependents"]=df["NumberOfDependents"].fillna(df["NumberOfDependents"].mode()[0])


# Outlier handling

upper_limit = df['MonthlyIncome'].quantile(.99)
lower_limit = df['MonthlyIncome'].quantile(.01)
df = df[(df['MonthlyIncome'] < upper_limit) &(df['MonthlyIncome'] > lower_limit)]

import pandas as pd
import numpy as np

df.replace('NA', np.nan, inplace=True)
df= df.apply(pd.to_numeric, errors='coerce')

# Store all numeric columns at once
numeric_df = df.select_dtypes(include=[np.number])

# Calculate Q1, Q3, IQR for ALL columns at once
Q1 = numeric_df.quantile(0.25)
Q3 = numeric_df.quantile(0.75)
IQR = Q3 - Q1

upper_limit = Q3 + 1.5 * IQR
lower_limit = Q1 - 1.5 * IQR

print("Upper Limits:\n", upper_limit)
print("\nLower Limits:\n", lower_limit)

# Count outliers for ALL columns at once
outliers_count = ((numeric_df > upper_limit) | (numeric_df < lower_limit)).sum()
print("\nTotal Extreme Transactions:\n", outliers_count)

# Clip ALL columns at once
clipped_df = numeric_df.clip(lower_limit, upper_limit, axis=1)

print("\nMaximum after clipping:\n", clipped_df.max())
print("\nMinimum after clipping:\n", clipped_df.min())

# # Models, FastAPI Backend and HTML Frontend
#
# 1. **Linear Regression** - predicts **salary** (the only salary model)
# 2. **Logistic Regression** - predicts **default risk**
# 3. **Decision Tree** - default risk
# 4. **Naive Bayes** - default risk
# 5. **Random Forest** - default risk
# 6. **SVM** - default risk

# ## 0. Preparing Data


import numpy as np
import pandas as pd
import joblib
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

# Remove the id column and turn everything into numbers
df = df.drop(columns=["Id"], errors="ignore")
df = df.replace("NA", float("nan"))
df = df.apply(pd.to_numeric, errors="coerce")

# Fill missing values (dependents -> most common value, everything else -> median)
df["NumberOfDependents"] = df["NumberOfDependents"].fillna(df["NumberOfDependents"].mode()[0])
df = df.fillna(df.median())

# The 9 inputs used by every model
features = [
    "RevolvingUtilizationOfUnsecuredLines",
    "age",
    "NumberOfTime30-59DaysPastDueNotWorse",
    "DebtRatio",
    "NumberOfOpenCreditLinesAndLoans",
    "NumberOfTimes90DaysLate",
    "NumberRealEstateLoansOrLines",
    "NumberOfTime60-89DaysPastDueNotWorse",
    "NumberOfDependents",
]
Xs_train, Xs_test, ys_train, ys_test = train_test_split(
    df[features], df["MonthlyIncome"], test_size=0.2, random_state=42)


risk_features = features + ["MonthlyIncome"]
Xr_train, Xr_test, yr_train, yr_test = train_test_split(
    df[risk_features], df["SeriousDlqin2yrs"], test_size=0.2, random_state=42,
    stratify=df["SeriousDlqin2yrs"])

risk_models = {}   
print("Salary rows (train/test):", len(Xs_train), "/", len(Xs_test))
print("Risk rows   (train/test):", len(Xr_train), "/", len(Xr_test))

# ## 1. Linear Regression (salary)

from sklearn.linear_model import LinearRegression

linear_model = LinearRegression()
linear_model.fit(Xs_train, ys_train)                 # learn from the training data

print("Linear Regression R2 on test data:", round(linear_model.score(Xs_test, ys_test), 4))

# ## 2. Logistic Regression (default risk)

from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

risk_models["logistic"] = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000))
risk_models["logistic"].fit(Xr_train, yr_train)

print("Logistic Regression accuracy:", round(risk_models["logistic"].score(Xr_test, yr_test), 4))

# ## 3. Decision Tree (default risk)

from sklearn.tree import DecisionTreeClassifier

risk_models["decision_tree"] = DecisionTreeClassifier(max_depth=6, min_samples_leaf=100, random_state=42)
risk_models["decision_tree"].fit(Xr_train, yr_train)

print("Decision Tree accuracy:", round(risk_models["decision_tree"].score(Xr_test, yr_test), 4))

# ## 4. Naive Bayes (default risk)

from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import QuantileTransformer
from sklearn.pipeline import make_pipeline

risk_models["naive_bayes"] = make_pipeline(
    QuantileTransformer(output_distribution="normal", n_quantiles=200, random_state=42),
    GaussianNB())
risk_models["naive_bayes"].fit(Xr_train, yr_train)

print("Naive Bayes accuracy:", round(risk_models["naive_bayes"].score(Xr_test, yr_test), 4))

# ## 5. Random Forest (default risk)

from sklearn.ensemble import RandomForestClassifier

risk_models["random_forest"] = RandomForestClassifier(
    n_estimators=100, max_depth=12, min_samples_leaf=20, n_jobs=-1, random_state=42)
risk_models["random_forest"].fit(Xr_train, yr_train)

print("Random Forest accuracy:", round(risk_models["random_forest"].score(Xr_test, yr_test), 4))

# ## 6. SVM (default risk)

from sklearn.svm import SVC
from sklearn.preprocessing import QuantileTransformer
from sklearn.pipeline import make_pipeline

sample = Xr_train.sample(n=15000, random_state=42)           # smaller sample = faster training
risk_models["svm"] = make_pipeline(
    QuantileTransformer(output_distribution="normal", n_quantiles=200, random_state=42),
    SVC(probability=True, random_state=42))                  # probability=True gives a % risk
risk_models["svm"].fit(sample, yr_train.loc[sample.index])

print("SVM accuracy:", round(risk_models["svm"].score(Xr_test, yr_test), 4))

# ## 7. Compare the models and save them

# ---------- Measure every model on the test data and save everything ----------
from sklearn.metrics import (r2_score, mean_absolute_error, mean_squared_error,
                             accuracy_score, roc_auc_score, recall_score, precision_score)

# --- Salary: Linear Regression ---
salary_pred = linear_model.predict(Xs_test)
salary_metrics = {
    "name": "Linear Regression",
    "r2": round(float(r2_score(ys_test, salary_pred)), 4),                          # 1.0 = perfect
    "mae": round(float(mean_absolute_error(ys_test, salary_pred)), 2),              # average $ error
    "rmse": round(float(np.sqrt(mean_squared_error(ys_test, salary_pred))), 2),
    "note": "Predicts salary only. Straight-line fit on 9 credit-profile inputs.",
}

# --- Default risk: the 5 classifiers ---
notes = {
    "logistic": "Predicts default risk. Gives a probability from a weighted sum of the inputs.",
    "decision_tree": "Predicts default risk using a chain of if/else questions (max depth 6).",
    "naive_bayes": "Predicts default risk using simple probability on quantile-normalised inputs.",
    "random_forest": "Predicts default risk by averaging 100 decision trees.",
    "svm": "Predicts default risk with an RBF SVM trained on a 15,000-row sample.",
}
names = {"logistic": "Logistic Regression", "decision_tree": "Decision Tree",
         "naive_bayes": "Naive Bayes", "random_forest": "Random Forest", "svm": "SVM"}

risk_metrics = {}
for key, model in risk_models.items():
    label = model.predict(Xr_test)                    # 0 / 1 answer
    proba = model.predict_proba(Xr_test)[:, 1]        # probability of default
    risk_metrics[key] = {
        "name": names[key],
        "accuracy": round(float(accuracy_score(yr_test, label)), 4),   # share of correct answers
        "roc_auc": round(float(roc_auc_score(yr_test, proba)), 4),     # how well risky/safe are ranked
        "recall": round(float(recall_score(yr_test, label)), 4),       # share of real defaulters caught
        "precision": round(float(precision_score(yr_test, label, zero_division=0)), 4),
        "note": notes[key],
    }

print("SALARY (Linear Regression):", {k: salary_metrics[k] for k in ["r2", "mae", "rmse"]})
table = pd.DataFrame(risk_metrics).T.set_index("name")[["accuracy", "roc_auc", "recall", "precision"]]
print("\nDEFAULT RISK models:\n", table.to_string())
print(f"\nBaseline: always answering 'no default' gives accuracy {1 - yr_test.mean():.4f}")
# Only ~6.7% of people default, so accuracy alone is misleading - look at ROC-AUC and recall too.

# --- Charts ---
fig, ax = plt.subplots(1, 2, figsize=(12, 3.8))
pick = np.random.RandomState(42).choice(len(ys_test), size=1500, replace=False)
ax[0].scatter(ys_test.to_numpy()[pick], salary_pred[pick], s=6, alpha=.4, color="#2563eb")
ax[0].plot([ys_test.min(), ys_test.max()], [ys_test.min(), ys_test.max()], "--", color="gray")
ax[0].set(title=f"Salary: Linear Regression (R² = {salary_metrics['r2']})",
          xlabel="Actual monthly income", ylabel="Predicted")
table["roc_auc"].astype(float).plot.barh(ax=ax[1], color="#16a34a", title="Default risk: ROC-AUC (higher is better)")
ax[1].set_ylabel("")
plt.tight_layout()
plt.show()

# --- Save the models so the web app can load them ---
joblib.dump(linear_model, MODELS_DIR / "regression_linear.joblib")               # the ONLY salary model
for key, model in risk_models.items():
    joblib.dump(model, MODELS_DIR / f"classification_{key}.joblib", compress=3)
joblib.dump({"regression": salary_metrics, "classification": risk_metrics}, MODELS_DIR / "credit_metrics.joblib")
print("\nSaved: 1 salary model (Linear Regression) + 5 default-risk models + metrics")
