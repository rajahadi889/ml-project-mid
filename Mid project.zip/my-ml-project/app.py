from pathlib import Path
from typing import Literal

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse


BASE = Path(__file__).resolve().parent
MODELS_DIR = BASE / "models"


RISK_KEYS = ["logistic", "decision_tree", "naive_bayes", "random_forest", "svm"]
ModelKey = Literal["linear", "logistic", "decision_tree", "naive_bayes", "random_forest", "svm"]
RiskKey = Literal["logistic", "decision_tree", "naive_bayes", "random_forest", "svm"]

MODEL_LABELS = {
    "linear": "Linear Regression",
    "logistic": "Logistic Regression",
    "decision_tree": "Decision Tree",
    "naive_bayes": "Naive Bayes",
    "random_forest": "Random Forest",
    "svm": "SVM",
}

metrics = joblib.load(MODELS_DIR / "credit_metrics.joblib")
salary_model = joblib.load(MODELS_DIR / "regression_linear.joblib")
risk_models = {k: joblib.load(MODELS_DIR / f"classification_{k}.joblib") for k in RISK_KEYS}

app = FastAPI(title="Credit Analysis API")


FIELDS = [
    ("revolving_utilization", "RevolvingUtilizationOfUnsecuredLines"),
    ("age", "age"),
    ("past_due_30_59", "NumberOfTime30-59DaysPastDueNotWorse"),
    ("debt_ratio", "DebtRatio"),
    ("open_credit_lines", "NumberOfOpenCreditLinesAndLoans"),
    ("times_90_days_late", "NumberOfTimes90DaysLate"),
    ("real_estate_loans", "NumberRealEstateLoansOrLines"),
    ("past_due_60_89", "NumberOfTime60-89DaysPastDueNotWorse"),
    ("dependents", "NumberOfDependents"),
]
RISK_FIELDS = FIELDS + [("monthly_income", "MonthlyIncome")]


def build_row(data: dict, fields):
    values = []
    for name, _ in fields:
        if name not in data:
            raise HTTPException(status_code=422, detail=f"Missing field: {name}")
        try:
            values.append(float(data[name]))
        except (TypeError, ValueError):
            raise HTTPException(status_code=422, detail=f"Field '{name}' must be a number")
    return pd.DataFrame([values], columns=[col for _, col in fields])



def run_salary(data: dict):
    X = build_row(data, FIELDS)
    value = max(float(salary_model.predict(X)[0]), 0)
    m = metrics["regression"]
    return {
        "prediction": round(value, 2),
        "annual": round(value * 12, 2),
        "model": m["name"],
        "model_key": "linear",
        "model_r2": m["r2"],
        "model_mae": m["mae"],
        "model_rmse": m["rmse"],
    }



def run_risk(key: str, data: dict):
    X = build_row(data, RISK_FIELDS)
    model = risk_models[key]
    prediction = int(model.predict(X)[0])
    probability = float(model.predict_proba(X)[0][1])
    m = metrics["classification"][key]
    return {
        "prediction": prediction,
        "label": "Likely to default" if prediction == 1 else "Unlikely to default",
        "default_probability": probability,
        "model": m["name"],
        "model_key": key,
        "model_accuracy": m["accuracy"],
        "model_auc": m["roc_auc"],
        "model_recall": m["recall"],
    }


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/models")
def list_models():
    """Fills the model menu. `task` tells the page what each model predicts:
    'salary' (Linear Regression only) or 'risk' (all the others)."""
    out = [{"key": "linear", "label": MODEL_LABELS["linear"], "task": "salary",
            "metrics": metrics["regression"]}]
    for k in RISK_KEYS:
        out.append({"key": k, "label": MODEL_LABELS[k], "task": "risk",
                    "metrics": metrics["classification"][k]})
    return out


@app.post("/predict/regression")
def predict_salary(data: dict):
    return run_salary(data)


@app.post("/predict/regression/{model_key}")
def predict_salary_with(model_key: ModelKey, data: dict):
    if model_key != "linear":
        raise HTTPException(status_code=400, detail="Salary is predicted by Linear Regression only.")
    return run_salary(data)


@app.post("/predict/classification")
def predict_risk(data: dict):
    return run_risk("logistic", data)


@app.post("/predict/classification/{model_key}")
def predict_risk_with(model_key: ModelKey, data: dict):
    if model_key == "linear":
        raise HTTPException(status_code=400, detail="Linear Regression predicts salary only, not default risk.")
    return run_risk(model_key, data)



@app.get("/")
def home():
    return FileResponse(BASE / "index.html")
