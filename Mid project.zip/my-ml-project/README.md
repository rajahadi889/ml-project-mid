# Credit Analysis

A small web app that uses machine learning on credit data. It does two things:

1. **Predicts monthly income (salary)** using Linear Regression.
2. **Predicts if a person is likely to default** (not pay back a loan) using one of five models:
   Logistic Regression, Decision Tree, Naive Bayes, Random Forest, or SVM.

You fill in a form on a web page, pick a model, and get the result.

## What is in this project

```
my-ml-project/
├── data/raw/cs-training.csv   The original dataset
├── models/                    Trained models (already included)
├── src/train.py               Trains the models and saves them in models/
├── app.py                     The backend (FastAPI) - this is what you run
├── index.html                 The web page (served by app.py)
├── requirements.txt           List of packages to install
└── README.md                  This file
```

## How to run it (VS Code)

You need Python 3.11 or newer.

**1. Open the `my-ml-project` folder in VS Code**
File -> Open Folder, then open a terminal: Terminal -> New Terminal.

**2. Create a virtual environment (only the first time)**
```
python -m venv venv
```

**3. Turn it on**
- Windows: `venv\Scripts\activate`
- Mac / Linux: `source venv/bin/activate`

You should see `(venv)` at the start of the terminal line.

**4. Install the packages (only the first time)**
```
pip install -r requirements.txt
```

**5. Start the app**
```
uvicorn app:app --reload
```

**6. Open the web page**
Go to http://127.0.0.1:8000 in your browser.

Keep the terminal open while you use the page. Press `Ctrl + C` to stop the app.

## Train the models again (optional)

The models in `models/` are already trained, so you can skip this.
If you want to train them again from the data:
```
python src/train.py
```
This takes a few minutes. A chart window may open - close it so training can continue.
After training, start the app again with step 5.

## Useful links (while the app is running)

- Web page: http://127.0.0.1:8000
- Check the app is working: http://127.0.0.1:8000/health
- Try the API in the browser: http://127.0.0.1:8000/docs

## If something goes wrong

- **The page says "Is the backend running?"** The app is not running. Do step 5 and keep the terminal open. Open the page from http://127.0.0.1:8000, not by double-clicking `index.html` or using Live Server.
- **"No module named ..."** The virtual environment is not on, or packages are not installed. Do steps 3 and 4.
- **"File not found"** Your terminal is in the wrong folder. It must be inside `my-ml-project`.
- **A scikit-learn version warning** Run `pip install -r requirements.txt` so you get the same version used to train the models.
